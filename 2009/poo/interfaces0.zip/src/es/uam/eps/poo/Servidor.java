package es.uam.eps.poo;

import java.rmi.Remote;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author Alejandro
 */
public interface Servidor extends Remote {

    /**
     * Obtiene la lista de eventos disponibles en el servidor dentro 
     * de un rango de fechas (ambos incluidos)
     *
     * @param desde límite inferior para el rango de fechas
     * @param hasta límite superior para el rango de fechas
     * @return una lista de eventos entre desde y hasta
     */
    public List<Evento> getEventos(Calendar desde, Calendar hasta);

    /**
     * Obtiene los eventos temporales en el servidor asociados a un evento y a un día
     *
     * @param e información sobre el evento
     * @param dia fecha en la que se quieren los eventos temporales
     * @return lista de eventos temporales asociados a e para la fecha dia
     */
    public List<EventoTemporal> getEventosTemporales(Evento e, Calendar dia);

    /**
     * Obtiene los recursos que no están ni reservados ni comprados
     * asociados a un evento temporal
     *
     * @param e evento temporal del que se quieren obtener los recursos
     * @return la lista de recursos libres asociados a e
     */
    public List<Recurso> getRecursosLibres(EventoTemporal e);

    /**
     * Este método devuelve un token si la reserva se ha realizado con éxito.
     * Dicho token permitirá al cliente mantener comunicaciones sucesivas con 
     * el servidor para poder completar la compra
     *
     * @param recursos lista de recursos que se quiere reservar
     * @return un token si la reserva de todos los recursos se ha podido efectuar con éxito, o null en otro caso
     */
    public Token reserva(List<Recurso> recursos);

    /**
     * Este método permite realizar la compra de unos recursos previamente reservados,
     * comprobando que la reserva sigue siendo válida 
     * (por ejemplo, el token no ha caducado, los recursos no han sido comprados, ...)
     *
     * @param token token que contiene información relativa a la reserva que se quiere comprar
     * @return true si la compra se ha realizado con éxito, false en otro caso
     */
    public boolean compra(Token token);

    /**
     * Este método permite anular una reserva previamente realizada.
     *
     * @param token token que contiene información relativa a la reserva que se quiere anular
     * @return true si la reserva se ha anulado con éxito, false en otro caso
     */
    public boolean anularReserva(Token token);
}
