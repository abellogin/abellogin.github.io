package es.uam.eps.poo;

import java.util.Calendar;

/**
 *
 * @author Alejandro
 */
public interface EventoTemporal {

    /**
     * Obtiene el momento en que comienza el evento
     *
     * @return día y hora en que comienza este evento
     */
    public Calendar getMomentoInicial();

    /**
     * Obtiene el momento en que termina el evento
     *
     * @return día y hora en que termina este evento
     */
    public Calendar getMomentoFinal();

    /**
     * Este método devuelve la localización (más específica) de este evento
     *
     * @return la localización en que se sitúa este evento
     */
    public Localizacion getLocalizacion();
}
