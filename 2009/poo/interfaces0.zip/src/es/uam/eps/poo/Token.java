package es.uam.eps.poo;

import java.util.List;

/**
 *
 * @author Alejandro
 */
public interface Token {

    /**
     * Obtiene el identificador único del token
     *
     * @return identificador único
     */
    public int getId();

    /**
     * Método que permite hacer comparaciones entre objetos de esta clase
     *
     * @param t token con el que se quiere comparar
     * @return true si t es igual a este token
     */
    public boolean equals(Token t);

    /**
     * Devuelve la lista de recursos asociados
     *
     * @return lista de recursos asociados a este token
     */
    public List<Recurso> getRecursos();

    /**
     * Devuelve el precio asociado
     *
     * @return precio asociado a este token
     */
    public double getPrecio();
}
