package es.uam.eps.poo;

/**
 *
 * @author Alejandro
 */
public interface Localizacion {

    /**
     * Este método permite a la clase Localización formar parte de otra Localización.
     *
     * @return null si esta localización no tiene padre, la localización padre en otro caso
     */
    public Localizacion getLocalizacionPadre();

    /**
     * Devuelve el nombre de la localización
     *
     * @return el nombre de esta localización
     */
    public String getNombre();
}
