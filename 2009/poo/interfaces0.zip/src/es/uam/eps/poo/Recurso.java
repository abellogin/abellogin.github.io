package es.uam.eps.poo;

/**
 *
 * @author Alejandro
 */
public interface Recurso {

    /**
     * Devuelve el identificador único de este recurso
     *
     * @return el identificador de este recurso
     */
    public int getId();

    /**
     * Comprueba si el recurso está reservado o no
     *
     * @return true si este recurso ya está reservado
     */
    public boolean estaReservado();

    /**
     * Comprueba si el recurso está comprado o no
     *
     * @return true si este recurso ya está comprado
     */
    public boolean estaComprado();

    /**
     * Comprueba si el recurso está libre (ni reservado ni comprado) o no
     *
     * @return true si este recurso está libre
     */
    public boolean estaLibre();

    /**
     * Devuelve el precio del recurso
     *
     * @return el precio de este recurso
     */
    public double getPrecioCompra();

    /**
     * Devuelve la localización asociada con el recurso
     *
     * @return la localización de este recurso
     */
    public Localizacion getLocalizacion();
}
