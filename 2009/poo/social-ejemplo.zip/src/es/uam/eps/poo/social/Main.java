/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.social;

import java.io.IOException;
import java.text.ParseException;
import org.jdom.JDOMException;

/**
 *
 * @author Profesores POO
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JDOMException, IOException, ExcepcionSocial, ParseException {
        RedSocial r = new RedSocial ("res/redsocial.xml");
    }
}
