/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.social;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.filter.ElementFilter;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author Profesores POO
 */
public class RedSocial {
    private HashMap<Long,Usuario> idUsuarios;
    private HashMap<String,Usuario> nickUsuarios;
    private Graph<Usuario,Relacion> red;
    public RedSocial (String url) throws JDOMException, IOException, ExcepcionSocial, ParseException {
        load (url);
    }

    public void load (String url) throws JDOMException, IOException, ExcepcionSocial, ParseException {
        idUsuarios = new HashMap<Long,Usuario> ();
        nickUsuarios = new HashMap<String,Usuario> ();
        red = new UndirectedSparseGraph<Usuario,Relacion> ();

        SAXBuilder parser = new SAXBuilder ();
        Document doc = parser.build (url);

        Iterator<Element> datosUsuarios = doc.getDescendants (new ElementFilter ("Usuario"));
        while (datosUsuarios.hasNext ()) {
            Element datosUsuario = datosUsuarios.next ();
            Usuario u = new Usuario (
                datosUsuario.getAttribute ("id") .getLongValue (),
                datosUsuario.getAttribute ("nick") .getValue (),
                datosUsuario.getAttribute ("password") .getValue (),
                datosUsuario.getAttribute ("nombre") .getValue (),
                this);
            idUsuarios.put (u.getId (), u);
            red.addVertex (u);
        }

        Iterator<Element> datosRelaciones = doc.getDescendants (new ElementFilter ("Relacion"));
        while (datosRelaciones.hasNext ()) {
            Element datosRelacion = datosRelaciones.next ();
            Attribute att = datosRelacion.getAttribute ("fecha");
            Date fecha = (att == null)? null : new SimpleDateFormat ("dd/MM/yyyy") .parse (att.getValue());
            Relacion r = new Relacion (
              getUsuario (datosRelacion.getAttribute ("origen") .getLongValue ()),
              getUsuario (datosRelacion.getAttribute ("destino") .getLongValue ()),
              fecha,
              this);
            red.addEdge (r, r.getOrigen (), r.getDestino ());
        }
    }

    public void save (String url) throws SQLException {
        // ...
    }

    public Usuario getUsuario (long id) {
        return idUsuarios.get (id);
    }

    public Usuario getUsuario (String nick) {
        return nickUsuarios.get (nick);
    }

    public Relacion addRelacion (Usuario u, Usuario v) throws JDOMException, ExcepcionSocial {
        // Nota: al crear una relación sin indicar fecha, se le asignará la fecha actual.
        Relacion r = new Relacion (u, v, this);
        red.addEdge (r, u, v);
        return r;
    }

    public boolean relacionados (Usuario u, Usuario v) {
        return red.isNeighbor (u, v);
    }
    
    public Collection<Usuario> getContactos (Usuario u) {
        return red.getNeighbors (u);
    }
}
