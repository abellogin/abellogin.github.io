/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.social;

/**
 *
 * @author Profesores POO
 */
public class ExcepcionIdDuplicado extends ExcepcionSocial {
    private long id;

    public ExcepcionIdDuplicado (long i) {
        id = i;
    }
    
    public String toString () {
        return "Error: el ID de usuario " + id + " ya existe.";
    }
}
