public interface Cliente<T extends RecursoTemporal, S extends Sistema> {

    public void reserva(T r, S s);

    public void compra(T r, S s);
}
