public interface Gestor<R extends Recurso, T extends RecursoTemporal, S extends Sistema> {

    public R creaRecurso(String idRecurso, S s, Posicion p);

    public T creaRecursoTemporal(R r, T t, S s);
}
