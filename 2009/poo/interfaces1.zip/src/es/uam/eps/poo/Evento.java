package es.uam.eps.poo;

import java.util.Calendar;

/**
 *
 * @author Alejandro
 */
public interface Evento {

    /**
     * Método que devuelve el nombre de este evento
     *
     * @return nombre del evento
     */
    public String getNombre();

    /**
     * Método que devuelve la fecha en que este evento empieza a producirse
     *
     * @return fecha en que comienza el evento
     */
    public Calendar getTiempoInicio();

    /**
     * Método que devuelve la fecha en que este evento deja de producirse
     *
     * @return fecha en que termina el evento
     */
    public Calendar getTiempoFin();
}
