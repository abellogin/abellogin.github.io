package es.uam.eps.irg.rs.trec.eval.rec;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * Methodology proposed in
 * "Factorization meets the neighborhood: a multifaceted collaborative filtering model"
 * Y. Koren. KDD 08
 * and further explained in
 * "Performance of recommender algorithms on top-N recommendation tasks"
 * P. Cremonesi, Y. Koren, R. Turrin. RecSys 2010
 *
 * It generates a ranking for each highly relevant item in the testing set,
 * using N additional random items
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingOneAndNItems extends TrecRecommenderEvaluatorUsingTestAndNItems {

    private float threshold;

    public TrecRecommenderEvaluatorUsingOneAndNItems(String itemsFile, int N, float threshold) {
        super(itemsFile, N);
        this.threshold = threshold;
    }

    public TrecRecommenderEvaluatorUsingOneAndNItems(String itemsFile, float threshold) {
        this(itemsFile, 500, threshold);
    }

    public TrecRecommenderEvaluatorUsingOneAndNItems(int N, float threshold) {
        this(null, N, threshold);
    }

    public TrecRecommenderEvaluatorUsingOneAndNItems(float threshold) {
        this(500, threshold);
    }

    @Override
    protected Map<Long, Float> getRelevantMap(long userID) {
        Map<Long, Float> map = super.getRelevantMap(userID);
        Map<Long, Float> m = new ConcurrentHashMap<Long, Float>();
        for (long i : map.keySet()) {
            if (map.get(i) >= threshold) {
                m.put(i, map.get(i));
            }
        }
        return m;
    }

    @Override
    protected void writeQrelFile(long userID, Map<Long, Float> relMap, String qrelFile) throws FileNotFoundException {
        PrintStream writerQrels = new PrintStream(new FileOutputStream(qrelFile, true));
        for (Map.Entry<Long, Float> e : relMap.entrySet()) {
            long itemID = e.getKey();
            int rel = e.getValue().intValue();
            // QUERY NAME = user + "_" + item
            writerQrels.println(userID + "_" + itemID + "\t0\t" + itemID + "\t" + rel);
        }
        writerQrels.close();
    }

    @Override
    protected synchronized void writeRanking(long userID, final Set<Long> relSet, final Map<Long, Set<Long>> notRelMap, final Map<Long, Float> userItemPreferenceMap, String recName, final PrintStream writer) {
        for (long rel : relSet) {
            final Map<Float, Set<Long>> preferenceMap = new HashMap<Float, Set<Long>>();
            // the value might be null if the estimated preference was NaN
            if (userItemPreferenceMap.get(rel) != null) {
                addItemToRanking(rel, userItemPreferenceMap.get(rel), preferenceMap);
                for (long notRel : notRelMap.get(rel)) {
                    // the value might be null if the estimated preference was NaN
                    if (userItemPreferenceMap.get(notRel) != null) {
                        addItemToRanking(notRel, userItemPreferenceMap.get(notRel), preferenceMap);
                    }
                }
                // Sort items by estimated preference
                final List<Float> sortedScores = new ArrayList<Float>(preferenceMap.keySet());
                Collections.sort(sortedScores, Collections.reverseOrder());
                // Write estimated preferences
                int pos = 1;
                for (float pref : sortedScores) {
                    for (long itemID : preferenceMap.get(pref)) {
                        // QUERY NAME = user + "_" + item
                        writer.println(userID + "_" + rel + "\tQ0\t" + itemID + "\t" + pos + "\t" + pref + "\t" + "r");
                        pos++;
                    }
                    if (pos > maxRankSize) {
                        break;
                    }
                }
            }
        }
    }

    @Override
    public String getItemsFileName() {
        return getOutputFolder() + "nOneAndNItemsFile_" + N + "_th" + threshold + ".txt";
    }

    @Override
    public String toString() {
        return "UsingOneAndNItems_" + N + "_th" + threshold;
    }
}
