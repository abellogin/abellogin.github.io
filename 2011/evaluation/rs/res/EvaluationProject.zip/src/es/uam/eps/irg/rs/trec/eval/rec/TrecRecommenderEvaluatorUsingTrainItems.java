package es.uam.eps.irg.rs.trec.eval.rec;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * Evaluation methodology which only uses the set of items contained in the training set
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingTrainItems extends AbstractTrecRecommenderEvaluator {

    private Set<Long> trainItems;

    public TrecRecommenderEvaluatorUsingTrainItems() {
        this.trainItems = new TreeSet<Long>();
    }

    @Override
    public void setTraining(Map<Long, Map<Long, Float>> train) {
        super.setTraining(train);
        trainItems.clear();
        for (long u : train.keySet()) {
            for (long i : train.get(u).keySet()) {
                trainItems.add(i);
            }
        }
    }

    @Override
    protected Map<Long, Float> getRelevantMap(long userID) {
        Map<Long, Float> map = super.getRelevantMap(userID);
        Map<Long, Float> m = new ConcurrentHashMap<Long, Float>();
        for (long i : map.keySet()) {
            if (trainItems.contains(i)) {
                m.put(i, map.get(i));
            }
        }
        return m;
    }

    @Override
    protected Set<Long> getNotRelevantSet(long userID) {
        Set<Long> nr = new TreeSet<Long>();
        for (long i : trainItems) {
            try {
                if (!train.get(userID).containsKey(i) && !test.get(userID).containsKey(i)) {
                    nr.add(i);
                }
            } catch (NullPointerException e) {
                // do nothing: if userId is not in training (or test)
                //             the algorithm will not be able to recommend anything
            }
        }
        return nr;
    }

    @Override
    public String toString() {
        return "UsingTrainItems";
    }
}
