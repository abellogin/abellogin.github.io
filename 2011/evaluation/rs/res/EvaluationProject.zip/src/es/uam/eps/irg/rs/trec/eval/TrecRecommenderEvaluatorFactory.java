package es.uam.eps.irg.rs.trec.eval;

import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingAllItems;
import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingOneAndNItems;
import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingTestAndNItems;
import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingTestItems;
import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingTestRatings;
import es.uam.eps.irg.rs.trec.eval.rec.TrecRecommenderEvaluatorUsingTrainItems;
import java.util.Map;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorFactory {

    public static final int DEFAULT_MAX_RANK = 1000;

    public static enum TREC_REC_EVALUATOR_TYPE {

        USING_ALL_ITEMS,
        USING_ONE_AND_N_ITEMS,
        USING_TEST_AND_N_ITEMS,
        USING_TEST_ITEMS,
        USING_TEST_RATINGS,
        USING_TRAIN_ITEMS;
    }

    /**
     *
     * This method creates the three evaluation methodologies which does not require any parameter.
     *
     * @param type type of evaluator
     * @return an instance of an evaluator with no parameter
     * @throws IllegalArgumentException if the type is incorrect
     */
    public static TrecRecommenderEvaluator getTrecRecommenderEvaluator(TREC_REC_EVALUATOR_TYPE type) {
        TrecRecommenderEvaluator eval = null;
        switch (type) {
            case USING_ALL_ITEMS:
                eval = new TrecRecommenderEvaluatorUsingAllItems();
                break;
            case USING_TEST_ITEMS:
                eval = new TrecRecommenderEvaluatorUsingTestItems();
                break;
            case USING_TRAIN_ITEMS:
                eval = new TrecRecommenderEvaluatorUsingTrainItems();
                break;
            default:
                throw new IllegalArgumentException();
        }
        return eval;
    }

    /**
     *
     * This method creates the other three evaluation methodologies which
     * require a small number of parameters.
     * By default, if the type does not match any of these methodologies,
     * #getTrecRecommenderEvaluator(TREC_REC_EVALUATOR_TYPE) is called.
     *
     * @param type type of evaluator
     * @param threshold relevance threshold: any rating greater or equal to this value is considered relevant
     * @param N number of not-relevant items to include in the evaluation
     * @param itemsFile file name where the relation of not-relevant items for each user is stored
     * @return an instance of an evaluator
     */
    public static TrecRecommenderEvaluator getTrecRecommenderEvaluator(TREC_REC_EVALUATOR_TYPE type,
            float threshold, int N, String itemsFile) {
        TrecRecommenderEvaluator eval = null;
        switch (type) {
            case USING_TEST_RATINGS:
                eval = new TrecRecommenderEvaluatorUsingTestRatings(threshold);
                break;
            case USING_TEST_AND_N_ITEMS:
                eval = new TrecRecommenderEvaluatorUsingTestAndNItems(itemsFile, N);
                break;
            case USING_ONE_AND_N_ITEMS:
                eval = new TrecRecommenderEvaluatorUsingOneAndNItems(itemsFile, N, threshold);
                break;
            default:
                return getTrecRecommenderEvaluator(type);
        }
        return eval;
    }

    /**
     *
     * This method allows for initialize with some data a given evaluator,
     * by calling the proper methods of the interface.
     *
     * @param evaluator evaluator to initialize
     * @param training training set
     * @param test test set
     * @param qrelFile file where qrels will be stored, or null
     * @param rec recommender
     * @param recName name of the recommender
     * @param outFolder folder where the recommender output will be generated
     */
    public static void initEvaluator(TrecRecommenderEvaluator evaluator,
            Map<Long, Map<Long, Float>> training, Map<Long, Map<Long, Float>> test,
            String qrelFile, String relFile,
            Recommender rec, String recName, String outFolder) {
        initEvaluator(evaluator, training, test, qrelFile, relFile, new Recommender[]{rec}, new String[]{recName}, outFolder);
    }

    /**
     *
     * This method allows for initialize with some data a given evaluator,
     * by calling the proper methods of the interface.
     *
     * @param evaluator evaluator to initialize
     * @param training training set
     * @param test test set
     * @param qrelFile file where qrels will be stored, or null
     * @param recs recommenders
     * @param recNames names of the recommenders
     * @param outFolder folder where the recommender output will be generated
     */
    public static void initEvaluator(TrecRecommenderEvaluator evaluator,
            Map<Long, Map<Long, Float>> training, Map<Long, Map<Long, Float>> test,
            String qrelFile, String relFile,
            Recommender[] recs, String[] recNames, String outFolder) {
        initEvaluator(evaluator, training, test, 0, 0, EvalUtils.getFixedRecommender(0), DEFAULT_MAX_RANK, false, qrelFile, relFile, recs, recNames, outFolder);
    }

    /**
     * 
     * This method allows for initialize with all the possible data a given evaluator,
     * by calling the proper methods of the interface.
     *
     * @param evaluator evaluator to initialize
     * @param training training set
     * @param test test set
     * @param userThreads number of threads to use (one for each user), 0 by default
     * @param recThreads number of threads to use (one for each recommender), 0 by default
     * @param wrappingRecommender recommender to use when the evaluated recommender is not able to return a recommendation, defualt: a dummy recommender which always returns 0
     * @param maxSize maximum length of the ranking list, 1000 by default
     * @param overwriteEvalFile flag to indicate whether the evaluation file should be overwritten or not, false by default
     * @param qrelFile file where qrels will be stored, or null
     * @param recs recommenders
     * @param recNames names of the recommenders
     * @param outFolder folder where the recommender output will be generated
     */
    public static void initEvaluator(TrecRecommenderEvaluator evaluator,
            final Map<Long, Map<Long, Float>> training, final Map<Long, Map<Long, Float>> test,
            int userThreads, int recThreads, final Recommender wrappingRecommender, int maxSize, boolean overwriteEvalFile,
            String qrelFile, String relFile,
            Recommender[] recs, String[] recNames, String outFolder) {
        if (recs.length != recNames.length) {
            throw new IllegalArgumentException("Lengths must be the same! " + recs.length + " and " + recNames.length);
        }
        evaluator.setTraining(training);
        evaluator.setTesting(test);
        evaluator.setWrappingRecommender(wrappingRecommender);
        evaluator.setUserThreads(userThreads);
        evaluator.setRecommenderThreads(recThreads);
        evaluator.setQrelFile(qrelFile);
        evaluator.setRelevantItemsFile(relFile);
        evaluator.setOverwriteEvalFile(overwriteEvalFile);
        evaluator.setMaxRankingSize(maxSize);
        for (int i = 0; i < recs.length; i++) {
            evaluator.addRecommender(recs[i], recNames[i], outFolder);
        }
    }
}
