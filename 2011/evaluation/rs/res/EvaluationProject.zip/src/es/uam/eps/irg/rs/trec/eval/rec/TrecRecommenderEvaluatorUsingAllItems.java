package es.uam.eps.irg.rs.trec.eval.rec;

import java.util.Set;
import java.util.TreeSet;

/**
 *
 * Evaluation methodology which uses the set of items contained in the training and testing set
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingAllItems extends AbstractTrecRecommenderEvaluator {

    private Set<Long> allItems;

    public TrecRecommenderEvaluatorUsingAllItems() {
        this.allItems = new TreeSet<Long>();
    }

    @Override
    public void evaluate() {
        allItems.clear();
        for (long u : train.keySet()) {
            for (long i : train.get(u).keySet()) {
                allItems.add(i);
            }
        }
        for (long u : test.keySet()) {
            for (long i : test.get(u).keySet()) {
                allItems.add(i);
            }
        }
        super.evaluate();
    }

    @Override
    protected Set<Long> getNotRelevantSet(long userID) {
        Set<Long> nr = new TreeSet<Long>();
        for (long i : allItems) {
            try {
                if (!train.get(userID).containsKey(i) && !test.get(userID).containsKey(i)) {
                    nr.add(i);
                }
            } catch (NullPointerException e) {
                // do nothing: if userId is not in training (or test)
                //             the algorithm will not be able to recommend anything
            }
        }
        return nr;
    }

    @Override
    public String toString() {
        return "UsingAllItems";
    }
}
