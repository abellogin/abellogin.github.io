package es.uam.eps.irg.rs.trec.eval.rec;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * Evaluation methodology which only uses the set of items contained in the
 * testing set for each user.
 * This class needs an additional parameter (threshold) in order to separate
 * the relevant from the not-relevant items
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingTestRatings extends AbstractTrecRecommenderEvaluator {

    private float threshold;

    public TrecRecommenderEvaluatorUsingTestRatings() {
        this(4.0f);
    }

    public TrecRecommenderEvaluatorUsingTestRatings(float threshold) {
        this.threshold = threshold;
    }

    @Override
    protected Map<Long, Float> getRelevantMap(long userID) {
        Map<Long, Float> map = super.getRelevantMap(userID);
        Map<Long, Float> m = new ConcurrentHashMap<Long, Float>();
        for (long i : map.keySet()) {
            if (map.get(i) >= threshold) {
                m.put(i, map.get(i));
            }
        }
        return m;
    }

    @Override
    protected Set<Long> getNotRelevantSet(long userID) {
        Set<Long> nr = new TreeSet<Long>();
        try {
            Map<Long, Float> map = super.getRelevantMap(userID);
            for (long i : map.keySet()) {
                if (map.get(i) < threshold) {
                    nr.add(i);
                }
            }
        } catch (NullPointerException e) {
            // do nothing: if userId is not in training (or test)
            //             the algorithm will not be able to recommend anything
        }
        return nr;
    }

    @Override
    public String toString() {
        return "UsingTestRatings_" + threshold;
    }
}
