package es.uam.eps.irg.rs.trec.eval.file.persistent;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * This class reads from file previously estimated preferences, in order
 * to use it as a dummy recommender.
 * For each estimation, it needs to scan the whole file.
 * 
 * @author Alejandro
 */
public class RecommenderResultFromFile implements Serializable, PersistentRecommender {

    private static final long serialVersionUID = 1232011322L;
    protected String inFile;
    protected int userPos;
    protected int itemPos;
    protected int ratPos;

    public RecommenderResultFromFile(Recommender rec, Map<Long, Map<Long, Integer>> test, String outFile) throws IOException {
        PrintStream ps = new PrintStream(new BufferedOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(outFile)))));
        for (long u : test.keySet()) {
            for (long i : test.get(u).keySet()) {
                try {
                    ps.println(u + "\t" + i + "\t" + rec.estimatePreference(u, i));
                } catch (Exception e) {
                    ps.println(u + "\t" + i + "\t" + Float.NaN);
                }
            }
        }
        ps.close();
    }

    public RecommenderResultFromFile(String inFile) {
        this(inFile, 0, 1, 2);
    }

    public RecommenderResultFromFile(String inFile, int userPos, int itemPos, int ratPos) {
        this.inFile = inFile;
        this.userPos = userPos;
        this.itemPos = itemPos;
        this.ratPos = ratPos;
    }

    public Float getPreference(long userId, long itemId) {
        try {
            BufferedReader br = getReader();
            String line = null;
            while ((line = br.readLine()) != null) {
                String[] toks = line.split("\t");
                long u = Long.parseLong(toks[userPos]);
                long i = Long.parseLong(toks[itemPos]);
                if (u == userId && i == itemId) {
                    float r = Float.parseFloat(toks[ratPos]);
                    br.close();
                    return r;
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Float.NaN;
    }

    protected BufferedReader getReader() throws IOException {
        if (inFile.endsWith(".tgz")) {
            return new BufferedReader(new InputStreamReader(new GZIPInputStream(new BufferedInputStream(new FileInputStream(inFile)))));
        }
        return new BufferedReader(new InputStreamReader(new BufferedInputStream(new FileInputStream(inFile))));
    }
}
