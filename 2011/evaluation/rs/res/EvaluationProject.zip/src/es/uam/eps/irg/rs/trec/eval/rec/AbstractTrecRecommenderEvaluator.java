package es.uam.eps.irg.rs.trec.eval.rec;

import es.uam.eps.irg.rs.trec.eval.TrecRecommenderEvaluator;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TimerTask;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.mahout.cf.taste.common.NoSuchUserException;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * Abstract class which implements a general evaluation methodology,
 * by ranking the relevant and not-relevant items for each user.
 *
 * @author Alejandro
 */
public abstract class AbstractTrecRecommenderEvaluator implements TrecRecommenderEvaluator {

    protected Map<Long, Map<Long, Float>> train;
    protected Map<Long, Map<Long, Float>> test;
    protected int userThreads;
    protected int recThreads;
    protected Recommender wrappingRec;
    protected int maxRankSize;
    protected boolean overwriteOutputFile;
    protected String qrelFile;
    protected String relFile;
    protected List<Recommender> recommenders;
    protected List<String> recommenderNames;

    public AbstractTrecRecommenderEvaluator() {
        this.recommenderNames = new ArrayList<String>();
        this.recommenders = new ArrayList<Recommender>();

        this.userThreads = 0;
        this.recThreads = 0;
        this.wrappingRec = null;
        this.maxRankSize = 1000;
        this.overwriteOutputFile = false;
        this.qrelFile = null;
        this.relFile = null;
    }

    /**
     * {@inheritDoc}
     */
    public void setTraining(Map<Long, Map<Long, Float>> train) {
        this.train = train;
    }

    /**
     * {@inheritDoc}
     */
    public void setTesting(Map<Long, Map<Long, Float>> test) {
        this.test = test;
    }

    /**
     * {@inheritDoc}
     *
     * No threads are used by default, i.e., nThreads=0
     *
     * @param nThreads {@inheritDoc}
     */
    public void setUserThreads(int nThreads) {
        this.userThreads = nThreads;
    }

    /**
     * {@inheritDoc}
     *
     * No threads are used by default, i.e., nThreads=0
     *
     * @param nThreads {@inheritDoc}
     */
    public void setRecommenderThreads(int nThreads) {
        this.recThreads = nThreads;
    }

    /**
     * {@inheritDoc}
     *
     * No wrapping recommender is used by default
     *
     * @param r {@inheritDoc}
     */
    public void setWrappingRecommender(Recommender r) {
        this.wrappingRec = r;
    }

    /**
     * {@inheritDoc}
     *
     * A value of 1000 is used by default
     *
     * @param maxSize {@inheritDoc}
     */
    public void setMaxRankingSize(int maxSize) {
        this.maxRankSize = maxSize;
    }

    /**
     *
     * {@inheritDoc}
     *
     * @param overwrite by default, false
     */
    public void setOverwriteEvalFile(boolean overwrite) {
        this.overwriteOutputFile = overwrite;
    }

    /**
     * {@inheritDoc}
     *
     * Null by default, i.e., qrel file will not be generated
     *
     * @param qrelFile
     */
    public void setQrelFile(String qrelFile) {
        this.qrelFile = qrelFile;
    }

    /**
     * {@inheritDoc}
     */
    public void setRelevantItemsFile(String relFile) {
        this.relFile = relFile;
    }

    public String getRelevantItemsFileName() {
        return getOutputFolder() + "relItemsFile_" + this + ".txt";
    }

    /**
     * {@inheritDoc}
     */
    public void addRecommender(Recommender r, String recName, String outFolder) {
        recommenders.add(r);
        recommenderNames.add(getFileName(outFolder, recName + "_" + this));
    }

    /**
     * {@inheritDoc}
     */
    public void evaluate() {
        final List<PrintStream> recStreams = new ArrayList<PrintStream>();
        for (int i = 0; i < recommenders.size(); i++) {
            String rec = recommenderNames.get(i);
            if ((!new File(rec).exists()) || (new File(rec).exists() && overwriteOutputFile)) {
                try {
                    recStreams.add(new PrintStream(new File(rec)));
                } catch (Exception e) {
                    e.printStackTrace();
                    recStreams.add(null);
                }
            } else {
                System.err.println("Ignoring " + rec);
                recStreams.add(null);
            }
        }
        // check if qrels file exists
        if (qrelFile != null) {
            if (new File(qrelFile).exists()) {
                System.err.println("Qrels file " + qrelFile + " will be rewritten");
                // and reset it
                try {
                    new PrintStream(new File(qrelFile)).close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        // check if relevant file exists
        PrintStream psRel = null;
        if (relFile == null) {
            relFile = getRelevantItemsFileName();
        }
        if (new File(relFile).exists()) {
            System.err.println("Relevant file " + relFile + " will be rewritten");
        }
        try {
            psRel = new PrintStream(new File(relFile));
        } catch (Exception e) {
            e.printStackTrace();
        }

        ExecutorService userPool = null;
        if (userThreads > 1) {
            userPool = Executors.newFixedThreadPool(userThreads);
        }
        for (long userID : test.keySet()) {
            // for each user
            // get a subset of her test set, i.e., those rated high
            // (depending on method 'isValidItemForTestSet')
            final Map<Long, Float> relMap = getRelevantMap(userID);
            if (relMap == null) {
                continue;
            }
            final Set<Long> relSet = getRelevantSet(userID);
            if ((relSet == null) || (relSet.isEmpty())) {
                continue;
            }
            // select N unrated items by this user
            final Map<Long, Set<Long>> notRelMap = getNotRelevantMap(userID, relSet);
            if ((notRelMap == null) || (notRelMap.isEmpty())) {
                continue;
            }
            // write qrels
            if (qrelFile != null) {
                try {
                    writeQrelFile(userID, relMap, qrelFile);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            // write relevant file
            if (psRel != null) {
                try {
                    writeRelevantItems(userID, relMap, psRel);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            final UserEvaluator ue = new UserEvaluator(userID, relSet, notRelMap, recommenders, recommenderNames, recStreams, recThreads);
            if (userPool == null) {
                ue.run();
            } else {
                userPool.execute(ue);
            }
        }
        if (userPool != null) {
            userPool.shutdown();
            try {
                while (!userPool.awaitTermination(10 * 24 * 60 * 60, TimeUnit.SECONDS)) {
                    System.err.println("Try again!");
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        // close files
        for (int i = 0; i < recommenders.size(); i++) {
            final PrintStream writer = recStreams.get(i);
            if (writer == null) {
                continue;
            }
            writer.close();
        }
        if (psRel != null) {
            psRel.close();
        }
    }

    private synchronized void estimatePreference(long userID, long itemID, final Recommender recommender, final Map<Long, Float> itemPreferenceMap) {
        float pref = Float.NaN;
        try {
            pref = recommender.estimatePreference(userID, itemID);
        } catch (NoSuchElementException nsee) {
        } catch (NoSuchUserException nsue) {
        } catch (TasteException te) {
        }
        if (Double.isNaN(pref)) {
            if (wrappingRec != null) {
                try {
                    pref = wrappingRec.estimatePreference(userID, itemID);
                } catch (NoSuchElementException nsee) {
                } catch (NoSuchUserException nsue) {
                } catch (TasteException te) {
                }
            }
        }
        // NaN is then sorted higher than any other value, and thus it should be removed
        if (!Double.isNaN(pref)) {
            itemPreferenceMap.put(itemID, pref);
        }
    }

    /**
     *
     * Returns the set of relevant items for a particular user.
     * By default it uses the output of #getRelevantMap(long),
     * by returning the keySet of that map.
     *
     * @param userID user id
     * @return set of relevant items for a user
     */
    protected Set<Long> getRelevantSet(long userID) {
        return getRelevantMap(userID).keySet();
    }

    /**
     *
     * Returns the map of relevant items for a particular user.
     * The map contains items in the keys, and their corresponding relevance
     * values in the values.
     *
     * @param userID user id
     * @return the map of relevant items for a user, if userID is not in the test set, an empty map is returned
     */
    protected Map<Long, Float> getRelevantMap(long userID) {
        if (test.containsKey(userID)) {
            return test.get(userID);
        } else {
            return new HashMap<Long, Float>();
        }
    }

    /**
     * Returns the set of not relevant items for a particular user.
     * This method depends on each evaluation methodology.
     *
     * @param userID user id
     * @return set of not relevant items for a user
     */
    protected abstract Set<Long> getNotRelevantSet(long userID);

    /**
     * Returns the set of not relevant items for a particular user and a particular item.
     * This method depends on each evaluation methodology.
     * By default, it returns the same set of items for every relevant item for a user.
     *
     * @param userID user id
     * @param items set of relevant items
     * @return set of not relevant items for a user
     */
    protected Map<Long, Set<Long>> getNotRelevantMap(long userID, Set<Long> items) {
        Map<Long, Set<Long>> map = new HashMap<Long, Set<Long>>();
        Set<Long> notRelSet = getNotRelevantSet(userID);
        for (long i : items) {
            map.put(i, notRelSet);
        }
        return map;
    }

    /**
     *
     * A generic implementation for generating a qrel file.
     * For each relevant item (#getRelevantMap(long)) a line in the file
     * is included with the following pattern:
     * userID \t 0 \t itemID \t relevanceValue
     *
     * @param userID user id
     * @param relMap map of relevant items for a user
     * @param qrelFile name of the file
     * @throws java.io.FileNotFoundException
     */
    protected void writeQrelFile(long userID, Map<Long, Float> relMap, String qrelFile) throws FileNotFoundException {
        PrintStream writerQrels = new PrintStream(new FileOutputStream(qrelFile, true));
        for (Map.Entry<Long, Float> e : relMap.entrySet()) {
            long itemID = e.getKey();
            int rel = e.getValue().intValue();
            writerQrels.println(userID + "\t0\t" + itemID + "\t" + rel);
        }
        writerQrels.close();
    }

    /**
     *
     * For each relevant item (#getRelevantMap(long)) a line in the file
     * is included with the following pattern:
     * userID \t itemID \t relevanceValue
     *
     * @param userID user id
     * @param relMap map of relevant items for a user
     * @param ps stream of the file
     * @throws java.io.FileNotFoundException
     */
    protected void writeRelevantItems(long userID, Map<Long, Float> relMap, PrintStream ps) throws FileNotFoundException {
        for (Map.Entry<Long, Float> e : relMap.entrySet()) {
            long itemID = e.getKey();
            int rel = e.getValue().intValue();
            ps.println(userID + "\t" + itemID + "\t" + rel);
        }
    }

    protected String getOutputFolder() {
        String f = null;
        for (String r : recommenderNames) {
            File ff = new File(r);
            f = ff.getParent() + "/";
            break;
        }
        return f;
    }

    /**
     *
     * A generic implementation for generating a ranking given a user and
     * her list of preferences.
     * For each preference included in userItemPreferenceMap (previously filled
     * with values generated by some recommender) a ranking is generated.
     * This ranking may contains less items than those in the union of relSet
     * and notRelSet, if additional constraints are included (#setMaxRankingSize(int)).
     * For each preference, a line is included in the file:
     * userID \t Q0 \t itemID \t position \t preferenceValue \t r
     *
     * @param userID user id
     * @param relSet set of relevant items for a user
     * @param notRelMap map of not-relevant items for a user
     * @param userItemPreferenceMap map containing the preferences inferred by some recommender for a user
     * @param recName name of the recommender which generated set of relevant items for a user
     * @param writer stream where the ranking will be written
     */
    protected synchronized void writeRanking(long userID, final Set<Long> relSet, final Map<Long, Set<Long>> notRelMap, final Map<Long, Float> userItemPreferenceMap, String recName, final PrintStream writer) {
        final Map<Float, Set<Long>> preferenceMap = new HashMap<Float, Set<Long>>();
        for (Entry<Long, Float> e : userItemPreferenceMap.entrySet()) {
            addItemToRanking(e.getKey(), e.getValue(), preferenceMap);
        }
        // Sort items by estimated preference
        final List<Float> sortedScores = new ArrayList<Float>(preferenceMap.keySet());
        Collections.sort(sortedScores, Collections.reverseOrder());
        // Write estimated preferences
        int pos = 1;
        for (float pref : sortedScores) {
            for (long itemID : preferenceMap.get(pref)) {
                writer.println(userID + "\tQ0\t" + itemID + "\t" + pos + "\t" + pref + "\t" + "r");
                pos++;
            }
            if (pos > maxRankSize) {
                break;
            }
        }
    }

    /**
     *
     * Convenience method which encapsulates some trivial operations over the current map of preferences
     *
     * @param item current item
     * @param pref preference towards an item (for some -unknown- user)
     * @param preferenceMap mapping of preferences for some user
     */
    protected static void addItemToRanking(long item, float pref, Map<Float, Set<Long>> preferenceMap) {
        Set<Long> items = preferenceMap.get(pref);
        if (items == null) {
            items = new TreeSet<Long>();
            preferenceMap.put(pref, items);
        }

        items.add(item);
    }

    /**
     *
     * Default name for the file where the recommendations (in the form of rankings)
     * will be generated.
     * By default, it is simply
     * outfolder "eval-" recommenderName ".txt"
     *
     * @param outFolder folder where the recommendation file will be generated
     * @param recommenderName name of the recommender
     * @return default name for the generated file
     */
    public static String getFileName(String outFolder, String recommenderName) {
        return outFolder + "eval-" + recommenderName + ".txt";
    }

    private class UserRecommenderEvaluator extends TimerTask {

        private long userID;
        private Set<Long> relSet;
        private Map<Long, Set<Long>> notRelMap;
        private PrintStream writer;
        private Recommender r;
        private String rec;
        private Map<Long, Float> userItemPreferenceMap;

        public UserRecommenderEvaluator(long userID, Set<Long> relSet, Map<Long, Set<Long>> notRelMap, PrintStream writer, Recommender r, String rec, Map<Long, Float> userItemPreferenceMap) {
            this.userID = userID;
            this.relSet = relSet;
            this.notRelMap = notRelMap;
            this.writer = writer;
            this.r = r;
            this.rec = rec;
            this.userItemPreferenceMap = userItemPreferenceMap;
        }

        @Override
        public void run() {
            for (long item : relSet) {
                estimatePreference(userID, item, r, userItemPreferenceMap);
                for (long itemN : notRelMap.get(item)) {
                    estimatePreference(userID, itemN, r, userItemPreferenceMap);
                }
            }
            writeRanking(userID, relSet, notRelMap, userItemPreferenceMap, rec, writer);
        }
    }

    private class UserEvaluator extends TimerTask {

        private long userID;
        private Set<Long> relSet;
        private Map<Long, Set<Long>> notRelMap;
        private List<Recommender> recs;
        private List<String> recNames;
        private List<PrintStream> streams;
        private int nThread;

        public UserEvaluator(long userID, Set<Long> relSet, Map<Long, Set<Long>> notRelMap, List<Recommender> recs, List<String> recNames, List<PrintStream> writer, int nThread) {
            this.userID = userID;
            this.relSet = relSet;
            this.notRelMap = notRelMap;
            this.recs = recs;
            this.recNames = recNames;
            this.streams = writer;
            this.nThread = nThread;
        }

        @Override
        public void run() {
            ExecutorService recPool = null;
            if (nThread > 1) {
                recPool = Executors.newFixedThreadPool(nThread);
            }
            for (int i = 0; i < recs.size(); i++) {
                final PrintStream writer = streams.get(i);
                if (writer == null) {
                    continue;
                }
                final Recommender r = recs.get(i);
                final String rec = recNames.get(i);
                final Map<Long, Float> userItemPreferenceMap = new HashMap<Long, Float>();
                final UserRecommenderEvaluator ue = new UserRecommenderEvaluator(userID, relSet, notRelMap, writer, r, rec, userItemPreferenceMap);
                if (recPool == null) {
                    ue.run();
                } else {
                    recPool.execute(ue);
                }
            }
            if (recPool != null) {
                recPool.shutdown();
                try {
                    while (!recPool.awaitTermination(10 * 24 * 60 * 60, TimeUnit.SECONDS)) {
                        System.err.println("Try again!");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
