package es.uam.eps.irg.rs.trec.eval.rec;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * Evaluation methodology which only uses the set of items contained in the testing set
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingTestItems extends AbstractTrecRecommenderEvaluator {

    private Set<Long> testItems;

    public TrecRecommenderEvaluatorUsingTestItems() {
        this.testItems = new TreeSet<Long>();
    }

    @Override
    public void setTesting(Map<Long, Map<Long, Float>> test) {
        super.setTesting(test);
        testItems.clear();
        for (long u : test.keySet()) {
            for (long i : test.get(u).keySet()) {
                testItems.add(i);
            }
        }
    }

    @Override
    protected Set<Long> getNotRelevantSet(long userID) {
        Set<Long> nr = new TreeSet<Long>();
        for (long i : testItems) {
            try {
                if (!train.get(userID).containsKey(i) && !test.get(userID).containsKey(i)) {
                    nr.add(i);
                }
            } catch (NullPointerException e) {
                // do nothing: if userId is not in training (or test)
                //             the algorithm will not be able to recommend anything
            }
        }
        return nr;
    }

    @Override
    public String toString() {
        return "UsingTestItems";
    }
}
