package es.uam.eps.irg.rs.trec.eval;

import es.uam.eps.irg.rs.trec.eval.file.persistent.PersistentRecommender;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastByIDMap;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.Preference;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.apache.mahout.cf.taste.recommender.IDRescorer;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * Class with (static) utility methods
 *
 * @author Alejandro
 */
public class EvalUtils {

    /**
     *
     * Method which transforms a model from Mahout's library into a map
     * of items and ratings for each user
     *
     * @param model data
     * @return map of users and item-rating mappings
     */
    public static Map<Long, Map<Long, Float>> fromDatamodelToMap(DataModel model) {
        Map<Long, Map<Long, Float>> m = new ConcurrentHashMap<Long, Map<Long, Float>>();
        try {
            LongPrimitiveIterator users = model.getUserIDs();
            while (users.hasNext()) {
                long user = users.nextLong();
                Map<Long, Float> prefs = new ConcurrentHashMap<Long, Float>();
                m.put(user, prefs);
                for (Preference pref : model.getPreferencesFromUser(user)) {
                    prefs.put(pref.getItemID(), pref.getValue());
                }
            }
        } catch (TasteException e) {
            e.printStackTrace();
        }
        return m;
    }

    /**
     *
     * Method which transforms a model from Mahout's library into a map
     * of items and ratings for each user
     *
     * @param model data
     * @return map of users and item-rating mappings
     */
    public static Map<Long, Map<Long, Float>> fromMapOfPreferencesToMap(FastByIDMap<PreferenceArray> model) {
        Map<Long, Map<Long, Float>> m = new ConcurrentHashMap<Long, Map<Long, Float>>();
        for (Entry<Long, PreferenceArray> e : model.entrySet()) {
            long user = e.getKey();
            Map<Long, Float> prefs = new ConcurrentHashMap<Long, Float>();
            m.put(user, prefs);
            for (Preference pref : e.getValue()) {
                prefs.put(pref.getItemID(), pref.getValue());
            }
        }
        return m;
    }

    /**
     *
     * This method creates a recommender which always return the same estimated preference.
     * It could be useful in order to generate dummy wrapping recommenders.
     *
     * @param rat value of the fixed preference to be estimated by the recommender
     * @return a recommender which always estimate the same preference
     * @see Recommender
     * @see TrecRecommenderEvaluator#setWrappingRecommender(Recommender)
     */
    public static Recommender getFixedRecommender(final float rat) {
        return new Recommender() {

            public List<RecommendedItem> recommend(long arg0, int arg1) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public List<RecommendedItem> recommend(long arg0, int arg1, IDRescorer arg2) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public float estimatePreference(long arg0, long arg1) throws TasteException {
                return rat;
            }

            public void setPreference(long arg0, long arg1, float arg2) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void removePreference(long arg0, long arg1) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public DataModel getDataModel() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void refresh(Collection<Refreshable> arg0) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
    }

    /**
     *
     * This method creates a recommender from an object which already contains
     * some pre-generated preferences for (every) pair of user and item.
     *
     * @param result object encoding already generated preference estimations
     * @return a recommender which returns the information encoded in result
     */
    public static Recommender getRecommenderFromResult(final PersistentRecommender result) {
        return new Recommender() {

            public List<RecommendedItem> recommend(long arg0, int arg1) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public List<RecommendedItem> recommend(long arg0, int arg1, IDRescorer arg2) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public float estimatePreference(long arg0, long arg1) throws TasteException {
                return result.getPreference(arg0, arg1);
            }

            public void setPreference(long arg0, long arg1, float arg2) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void removePreference(long arg0, long arg1) throws TasteException {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public DataModel getDataModel() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void refresh(Collection<Refreshable> arg0) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
    }

    /**
     *
     * This methods allows to obtain the complete dataset from a training-test split
     *
     * @param training one of the data splits
     * @param test another data splits
     * @return a restored version of the data, based on the two splits given
     */
    public static Map<Long, Map<Long, Float>> getCompleteDataset(final Map<Long, Map<Long, Float>> training, final Map<Long, Map<Long, Float>> test) {
        final Map<Long, Map<Long, Float>> data = new HashMap<Long, Map<Long, Float>>();
        for (long u : training.keySet()) {
            Map<Long, Float> m = new HashMap<Long, Float>();
            data.put(u, m);
            for (long i : training.get(u).keySet()) {
                m.put(i, training.get(u).get(i));
            }
        }
        for (long u : test.keySet()) {
            Map<Long, Float> m = data.get(u);
            if (m == null) {
                m = new HashMap<Long, Float>();
                data.put(u, m);
            }
            for (long i : test.get(u).keySet()) {
                m.put(i, test.get(u).get(i));
            }
        }
        return data;
    }
}
