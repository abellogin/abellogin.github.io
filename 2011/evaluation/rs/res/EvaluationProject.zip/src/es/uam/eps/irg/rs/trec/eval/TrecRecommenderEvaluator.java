package es.uam.eps.irg.rs.trec.eval;

import java.util.Map;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * Interface which must be implemented by any evaluator methodology
 *
 * @author Alejandro
 */
public abstract interface TrecRecommenderEvaluator {

    /**
     *
     * Assigns the current training set
     *
     * @param train user-item matrix encoded as a map of users and map of items and ratings
     * @see EvalUtils#fromDatamodelToMap(org.apache.mahout.cf.taste.model.DataModel) 
     */
    public void setTraining(Map<Long, Map<Long, Float>> train);

    /**
     * Assigns the current testing set
     *
     * @param test user-item matrix encoded as a map of users and map of items and ratings
     * @see EvalUtils#fromDatamodelToMap(org.apache.mahout.cf.taste.model.DataModel) 
     * @see EvalUtils#fromMapOfPreferencesToMap(org.apache.mahout.cf.taste.impl.common.FastByIDMap)
     */
    public void setTesting(Map<Long, Map<Long, Float>> test);

    /**
     *
     * Sets the number of threads to be used when evaluating, one for each user.
     *
     * @param nThreads number of threads to use, if nThreads < 1, no threads will be used
     */
    public void setUserThreads(int nThreads);

    /**
     *
     * Sets the number of threads to be used when evaluating, one for each recommender.
     *
     * @param nThreads number of threads to use, if nThreads < 1, no threads will be used
     */
    public void setRecommenderThreads(int nThreads);

    /**
     *
     * Recommender to be used when the evaluated recommender is not able
     * to recommend some item for a user (i.e., it returns a NaN).
     * It could be useful to ensure that all the recommenders are evaluated
     * under the same conditions (every ranking has the same length).
     *
     * @param r recommender to use when the evaluated recommender fails to estimate some preference
     */
    public void setWrappingRecommender(Recommender r);

    /**
     *
     * Sets the maximum length of the generated ranking.
     *
     * @param maxSize maximum lenght of the ranking
     */
    public void setMaxRankingSize(int maxSize);

    /**
     *
     * Flag to indicate whether the methodology should overwrite or not
     * a file, in the case it is already found in the system.
     *
     * @param overwrite flag
     */
    public void setOverwriteEvalFile(boolean overwrite);

    /**
     *
     * File where the groundtruth information will be stored.
     *
     * @param qrelFile null if qrel should not be generated
     */
    public void setQrelFile(String qrelFile);

    /**
     *
     * File where the relevant items per user will be stored.
     *
     * @param relFile name of the file to be generated
     */
    public void setRelevantItemsFile(String relFile);

    /**
     *
     * This method adds a recommender in the evaluator.
     * The folder and recommender name are used to generate the file name.
     *
     * @param r recommender to evaluate
     * @param recName name of the recommender
     * @param outFolder folder where the file will be generate
     */
    public void addRecommender(Recommender r, String recName, String outFolder);

    /**
     *
     * Evaluates every recommender submitted, according to the strategy defined by each methodology.
     *
     */
    public void evaluate();
}
