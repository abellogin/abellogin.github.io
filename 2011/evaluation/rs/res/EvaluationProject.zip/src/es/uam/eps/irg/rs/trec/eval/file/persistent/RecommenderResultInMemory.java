package es.uam.eps.irg.rs.trec.eval.file.persistent;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * This class reads from file previously estimated preferences, in order
 * to use it as a dummy recommender.
 * It keeps all the information in memory.
 *
 * @author Alejandro
 */
public class RecommenderResultInMemory implements Serializable, PersistentRecommender {

    private static final long serialVersionUID = 1232011321L;
    private Map<Long, Map<Long, Float>> ratings;

    public RecommenderResultInMemory(Recommender rec, Map<Long, Map<Long, Integer>> test) {
        ratings = new ConcurrentHashMap<Long, Map<Long, Float>>();
        for (long u : test.keySet()) {
            Map<Long, Float> rats = new ConcurrentHashMap<Long, Float>();
            ratings.put(u, rats);
            for (long i : test.get(u).keySet()) {
                try {
                    rats.put(i, rec.estimatePreference(u, i));
                } catch (Exception e) {
                    rats.put(i, Float.NaN);
                }
            }
        }
    }

    private RecommenderResultInMemory(Map<Long, Map<Long, Float>> ratings) {
        this.ratings = ratings;
    }

    public Float getPreference(long userId, long itemId) {
        Map<Long, Float> rats = ratings.get(userId);
        if (rats != null) {
            if (rats.containsKey(itemId)) {
                return rats.get(itemId);
            }
        }
        return Float.NaN;
    }

    public static RecommenderResultInMemory load(String file) throws ClassNotFoundException, IOException {
        InputStream fis = new BufferedInputStream(new FileInputStream(file));
        GZIPInputStream gzip = new GZIPInputStream(fis);
        ObjectInputStream ois = new ObjectInputStream(gzip);
        Map<Long, Map<Long, Float>> m = (Map<Long, Map<Long, Float>>) ois.readObject();
        ois.close();
        return new RecommenderResultInMemory(m);
    }

    public void store(String file) throws IOException {
        OutputStream fos = new BufferedOutputStream(new FileOutputStream(file));
        GZIPOutputStream gzip = new GZIPOutputStream(fos);
        ObjectOutputStream oos = new ObjectOutputStream(gzip);
        oos.writeObject(ratings);
        oos.close();
    }
}
