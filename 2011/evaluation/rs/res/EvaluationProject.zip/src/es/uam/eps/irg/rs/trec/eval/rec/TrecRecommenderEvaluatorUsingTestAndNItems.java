package es.uam.eps.irg.rs.trec.eval.rec;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.apache.mahout.cf.taste.common.TasteException;

/**
 *
 * Evaluation methodology which uses a limited set of items contained in
 * the testing set as not relevant set (constrained by parameter N)
 *
 * @author Alejandro
 */
public class TrecRecommenderEvaluatorUsingTestAndNItems extends AbstractTrecRecommenderEvaluator {

    protected String itemsFile;
    protected int N;
    protected Set<Long> testItems;
    protected Map<Long, Set<Long>> notRelevantItemsMap;

    public TrecRecommenderEvaluatorUsingTestAndNItems() {
        this(100);
    }

    public TrecRecommenderEvaluatorUsingTestAndNItems(int N) {
        this(null, N);
    }

    public TrecRecommenderEvaluatorUsingTestAndNItems(String itemsFile) {
        this(itemsFile, 100);
    }

    public TrecRecommenderEvaluatorUsingTestAndNItems(String itemsFile, int N) {
        this.itemsFile = itemsFile;
        this.N = N;
        this.testItems = new TreeSet<Long>();
    }

    private Set<Long> getUserNotRelevantItems(long userId) throws TasteException {
        // get all unrated items by this user
        Set<Long> unratedItems = new TreeSet<Long>();
        for (long i : testItems) {
            try {
                if (!train.get(userId).containsKey(i) && !test.get(userId).containsKey(i)) {
                    unratedItems.add(i);
                }
            } catch (NullPointerException e) {
                // do nothing: if userId is not in training (or test)
                //             the algorithm will not be able to recommend anything
            }
        }
        // randomize and cut this set
        List<Long> auxList = new ArrayList<Long>(unratedItems);
        Collections.shuffle(auxList);
        int n = Math.min(auxList.size(), N);
        return new TreeSet<Long>(auxList.subList(0, n));
    }

    private Map<Long, Set<Long>> getUserNotRelevantItemsMap() {
        Map<Long, Set<Long>> map = new HashMap<Long, Set<Long>>();
        if (itemsFile == null) {
            itemsFile = getItemsFileName();
        }
        if (new File(itemsFile).exists()) {
            System.out.println("Reading itemsFile from file " + itemsFile);
            try {
                BufferedReader br = new BufferedReader(new FileReader(itemsFile));
                String line = null;
                while ((line = br.readLine()) != null) {
                    String[] toks = line.split("\t");
                    long user = Long.parseLong(toks[0]);
                    long item = Long.parseLong(toks[1]);
                    Set<Long> items = map.get(user);
                    if (items == null) {
                        items = new TreeSet<Long>();
                        map.put(user, items);
                    }
                    items.add(item);
                }
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            // generate map
            for (long userID : test.keySet()) {
                try {
                    Set<Long> notRelSet = getUserNotRelevantItems(userID);
                    map.put(userID, notRelSet);
                } catch (TasteException e) {
                    e.printStackTrace();
                }
            }
            // save it to file
            try {
                PrintStream out = new PrintStream(itemsFile);
                for (long user : map.keySet()) {
                    for (long item : map.get(user)) {
                        out.println(user + "\t" + item);
                    }
                }
                out.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

    public String getItemsFileName() {
        return getOutputFolder() + "nTestAndNItemsFile_" + N + ".txt";
    }

    @Override
    public void evaluate() {
        testItems.clear();
        for (long u : train.keySet()) {
            for (long i : train.get(u).keySet()) {
                testItems.add(i);
            }
        }
        for (long u : test.keySet()) {
            for (long i : test.get(u).keySet()) {
                testItems.add(i);
            }
        }
        notRelevantItemsMap = getUserNotRelevantItemsMap();
        super.evaluate();
    }

    @Override
    protected Set<Long> getNotRelevantSet(long userID) {
        return notRelevantItemsMap.get(userID);
    }

    @Override
    public String toString() {
        return "UsingTestAndNItems_" + N;
    }
}
