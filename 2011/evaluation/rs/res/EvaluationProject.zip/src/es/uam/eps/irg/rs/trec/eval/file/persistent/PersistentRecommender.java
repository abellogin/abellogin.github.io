package es.uam.eps.irg.rs.trec.eval.file.persistent;

/**
 *
 *
 * @author Alejandro
 */
public interface PersistentRecommender {

    public Float getPreference(long userId, long itemId);
}
