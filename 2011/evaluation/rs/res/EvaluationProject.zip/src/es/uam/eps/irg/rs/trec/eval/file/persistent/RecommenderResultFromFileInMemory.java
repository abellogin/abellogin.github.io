package es.uam.eps.irg.rs.trec.eval.file.persistent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * This class reads from file previously estimated preferences, in order
 * to use it as a dummy recommender.
 * It stores in memory the whole file.
 *
 * @author Alejandro
 */
public class RecommenderResultFromFileInMemory extends RecommenderResultFromFile implements Serializable, PersistentRecommender {

    private static final long serialVersionUID = 3232011322L;
    private Map<Long, Map<Long, Float>> ratings;

    public RecommenderResultFromFileInMemory(String inFile) {
        super(inFile);
        this.ratings = new ConcurrentHashMap<Long, Map<Long, Float>>();
        readFile();
    }

    public RecommenderResultFromFileInMemory(String inFile, int userPos, int itemPos, int ratPos) {
        super(inFile, userPos, itemPos, ratPos);
        this.ratings = new ConcurrentHashMap<Long, Map<Long, Float>>();
        readFile();
    }

    public RecommenderResultFromFileInMemory(Recommender rec, Map<Long, Map<Long, Integer>> test, String outFile) throws IOException {
        super(rec, test, outFile);
    }

    private void readFile() {
        try {
            BufferedReader br = getReader();
            String line = null;
            while ((line = br.readLine()) != null) {
                String[] toks = line.split("\t");
                long u = Long.parseLong(toks[userPos]);
                long i = Long.parseLong(toks[itemPos]);
                float r = Float.parseFloat(toks[ratPos]);
                Map<Long, Float> m = ratings.get(u);
                if (m == null) {
                    m = new ConcurrentHashMap<Long, Float>();
                    ratings.put(u, m);
                }
                m.put(i, r);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Float getPreference(long userId, long itemId) {
        Float p = null;
        if (ratings.containsKey(userId)) {
            p = ratings.get(userId).get(itemId);
        }
        return p == null ? Float.NaN : p;
    }
}
