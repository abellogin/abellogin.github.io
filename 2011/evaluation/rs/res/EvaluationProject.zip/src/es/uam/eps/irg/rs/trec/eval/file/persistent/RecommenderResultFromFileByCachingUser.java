package es.uam.eps.irg.rs.trec.eval.file.persistent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 *
 * This class reads from file previously estimated preferences, in order
 * to use it as a dummy recommender.
 * Besides, it caches the results regarding the last user asked for.
 *
 * @author Alejandro
 */
public class RecommenderResultFromFileByCachingUser extends RecommenderResultFromFile implements Serializable, PersistentRecommender {

    private static final long serialVersionUID = 1232011322L;
    private long lastUserId;
    private Map<Long, Float> lastPreferences;

    public RecommenderResultFromFileByCachingUser(String inFile) {
        super(inFile);
        this.lastUserId = -1;
        this.lastPreferences = null;
    }

    public RecommenderResultFromFileByCachingUser(Recommender rec, Map<Long, Map<Long, Integer>> test, String outFile) throws IOException {
        super(rec, test, outFile);
    }

    @Override
    public Float getPreference(long userId, long itemId) {
        if (userId != lastUserId) {
            lastUserId = userId;
            lastPreferences = new ConcurrentHashMap<Long, Float>();
            try {
                BufferedReader br = getReader();
                String line = null;
                while ((line = br.readLine()) != null) {
                    String[] toks = line.split("\t");
                    long u = Long.parseLong(toks[0]);
                    if (u == userId) {
                        long i = Long.parseLong(toks[1]);
                        float r = Float.parseFloat(toks[2]);
                        lastPreferences.put(i, r);
                    }
                }
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Float p = lastPreferences.get(itemId);
        return p == null ? Float.NaN : p;
    }
}
