package es.uam.eps.poo.rmi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Alejandro
 */
public class ServidorMain {

    public static void main(String[] args) throws InterruptedException {
        try {
            final TiendaRemota tienda = new Libreria();
            UnicastRemoteObject.exportObject(tienda, 0);
            Registry registry = LocateRegistry.createRegistry(TiendaRemota.Port);
            registry.rebind(TiendaRemota.ID, tienda);
            System.out.println("Tienda remota registrado");
        } catch (Exception e) {
            System.err.println("Error al registrar tienda");
            e.printStackTrace();
            System.exit(1);
        }
    }
}
