package es.uam.eps.poo;

import java.util.List;

/**
 *
 * @author Alejandro
 */
public interface Tienda {

    public void venderCarrito(Cliente c1);

    public void mostrarStock(Articulo a);

    public Cliente getCliente(String string);

    public List<Articulo> getArticulos();
}
