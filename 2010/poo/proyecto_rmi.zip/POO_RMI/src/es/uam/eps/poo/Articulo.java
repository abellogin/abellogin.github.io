package es.uam.eps.poo;

/**
 *
 * @author Alejandro
 */
public class Articulo {

    private String nombre;

    public Articulo(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Articulo other = (Articulo) obj;
        if ((this.nombre == null) ? (other.nombre != null) : !this.nombre.equals(other.nombre)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + (this.nombre != null ? this.nombre.hashCode() : 0);
        return hash;
    }
}
