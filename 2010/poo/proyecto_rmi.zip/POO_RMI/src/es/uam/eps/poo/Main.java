package es.uam.eps.poo;

/**
 *
 * @author Alejandro
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        final Tienda tienda = new Libreria();
        final Articulo a = tienda.getArticulos().get(0);
        final Cliente c1 = tienda.getCliente("1");
        final Cliente c2 = tienda.getCliente("2");
        Thread hilo1 = new Thread() {

            @Override
            public void run() {
                c1.meterAlCarrito(a, 1);
                tienda.venderCarrito(c1);
            }
        };
        Thread hilo2 = new Thread() {

            @Override
            public void run() {
                c2.meterAlCarrito(a, 1);
                tienda.venderCarrito(c2);
            }
        };
        hilo2.start();
        hilo1.start();
        Thread.sleep(1000);
        tienda.mostrarStock(a);
    }
}
