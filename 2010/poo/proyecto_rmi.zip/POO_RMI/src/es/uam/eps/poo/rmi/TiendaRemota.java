package es.uam.eps.poo.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author Alejandro
 */
public interface TiendaRemota extends Remote {

    /**
     * Nombre con el que se registra en RMI
     */
    public static final String ID = "tienda";
    /**
     * Puerto del registro
     */
    public static final int Port = 1234;

    public void venderCarrito(Cliente c1) throws RemoteException;

    public void mostrarStock(Articulo a) throws RemoteException;

    public int getStock(Articulo a) throws RemoteException;

    public Cliente getCliente(String string) throws RemoteException;

    public List<Articulo> getArticulos() throws RemoteException;
}
