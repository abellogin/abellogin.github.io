package es.uam.eps.poo.rmi;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alejandro
 */
public class Cliente /* implements Serializable */ {

    private List<Articulo> carrito = new ArrayList<Articulo>();
    private String nombre;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public void meterAlCarrito(Articulo a, int i) {
        System.out.println("Metiendo en el carrito...");
        carrito.add(a);
    }

    public List<Articulo> getCarrito() {
        return carrito;
    }

    public String getNombre() {
        return nombre;
    }
}
