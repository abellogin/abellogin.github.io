package es.uam.eps.poo.rmi;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Alejandro
 */
public class ClienteMain {

    public static void main(String[] args) throws InterruptedException {
        try {
            Registry r = LocateRegistry.getRegistry(TiendaRemota.Port);
            final TiendaRemota tienda = (TiendaRemota) r.lookup(TiendaRemota.ID);

            // hacer cosas con la tienda
            final Articulo a = tienda.getArticulos().get(0);
            final Cliente c1 = tienda.getCliente("1");
            final Cliente c2 = tienda.getCliente("2");
            Thread hilo1 = new Thread() {

                @Override
                public void run() {
                    c1.meterAlCarrito(a, 1);
                    try {
                        tienda.venderCarrito(c1);
                    } catch (RemoteException ex) {
                        ex.printStackTrace();
                    }
                }
            };
            Thread hilo2 = new Thread() {

                @Override
                public void run() {
                    c2.meterAlCarrito(a, 1);
                    try {
                        tienda.venderCarrito(c2);
                    } catch (RemoteException ex) {
                        ex.printStackTrace();
                    }
                }
            };
            hilo2.start();
            hilo1.start();
            Thread.sleep(1000);
            tienda.mostrarStock(a);

            System.out.println(tienda.getStock(a));
        } catch (NotBoundException ex) {
            ex.printStackTrace();
        } catch (AccessException ex) {
            ex.printStackTrace();
        } catch (RemoteException ex) {
            ex.printStackTrace();
        }
    }
}
