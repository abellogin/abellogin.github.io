package es.uam.eps.poo.gui;

import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

/**
 *
 * @author Alejandro
 */
public class MyTable extends JTable {

    protected String[] columnToolTips = {null, null, "Deporte favorito", "años", "etc."};

    public MyTable() {
        super(new Object[][] {
            {"Maria", "A.", "Snowboarding", 25, "Nada"},
            {"Sara", "B.", "Vela", 18, "..."}},
            new String[]{"Nombre", "Apellido", "Afición", "Edad", "Otras cosas"});
    }

    @Override
    protected JTableHeader createDefaultTableHeader() {
        return new JTableHeader(columnModel) {

            @Override
            public String getToolTipText(MouseEvent event) {
                String tip = null;
                Point p = event.getPoint();
                int index = columnModel.getColumnIndexAtX(p.x);
                int realIndex = columnModel.getColumn(index).getModelIndex();
                return columnToolTips[realIndex];
            }
        };
    }
}
