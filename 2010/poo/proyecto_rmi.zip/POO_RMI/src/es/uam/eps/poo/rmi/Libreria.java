package es.uam.eps.poo.rmi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Alejandro
 */
public class Libreria implements TiendaRemota {

    private Map<Articulo, Integer> almacen;

    public Libreria() {
        almacen = new HashMap<Articulo, Integer>();
        almacen.put(new Articulo("test"), 2);
    }

    public synchronized void venderCarrito(Cliente cl) {
        for (Articulo a : cl.getCarrito()) {
            almacen.put(a, almacen.get(a) - 1);
        }
        cl.getCarrito().clear();
    }

    public void mostrarStock(Articulo a) {
        System.out.println("Stock:" + almacen.get(a));
    }

    public int getStock(Articulo a) {
        return almacen.get(a);
    }

    public Cliente getCliente(String string) {
        return new Cliente(string);
    }

    public List<Articulo> getArticulos() {
        return new ArrayList<Articulo>(almacen.keySet());
    }
}
