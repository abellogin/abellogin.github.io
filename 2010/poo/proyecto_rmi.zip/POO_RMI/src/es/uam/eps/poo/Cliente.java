package es.uam.eps.poo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alejandro
 */
public class Cliente {

    private List<Articulo> carrito = new ArrayList<Articulo>();
    private String nombre;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public void meterAlCarrito(Articulo a, int i) {
        carrito.add(a);
    }

    public List<Articulo> getCarrito() {
        return carrito;
    }

    public String getNombre() {
        return nombre;
    }
}
