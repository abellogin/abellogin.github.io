package es.uam.eps.poo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;

/**
 *
 * @author Alejandro
 */
public class Libreria implements Tienda {

    private Map<Articulo, Integer> almacen;
    private Semaphore sem;

    public Libreria() {
        almacen = new HashMap<Articulo, Integer>();
        almacen.put(new Articulo("test"), 2);
        sem = new Semaphore(1);
    }

    public void venderCarrito(Cliente cl) {
        try {
            sem.acquire();
        } catch (InterruptedException e) {
        }
        for (Articulo a : cl.getCarrito()) {
            almacen.put(a, almacen.get(a) - 1);
        }
        sem.release();
        cl.getCarrito().clear();
    }

    public void mostrarStock(Articulo a) {
        System.out.println("Stock:" + almacen.get(a));
    }

    public Cliente getCliente(String string) {
        return new Cliente(string);
    }

    public List<Articulo> getArticulos() {
        return new ArrayList<Articulo>(almacen.keySet());
    }
}
