package es.uam.eps.poo.gui;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Alejandro
 */
public class MyTableModel extends AbstractTableModel {

    private Object[][] data = {
        {"Clase", "de", "POO", 2, new JButton("A"), new ImageIcon("uno.gif")},
        {"Clase", "de", "EDI", 1, new JButton("B"), new ImageIcon("uno.gif")},
        {"Clase", "de", "GEO", 4, new JButton("C"), new ImageIcon("uno.gif")}};

    public int getRowCount() {
        return data.length;
    }

    public int getColumnCount() {
        return data[0].length;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return data[0][columnIndex].getClass();
    }

    public void setData(Object[][] data) {
        this.data = data;
        fireTableDataChanged();
    }
}
