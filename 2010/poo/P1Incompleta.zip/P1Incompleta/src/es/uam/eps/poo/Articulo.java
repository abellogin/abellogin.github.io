/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uam.eps.poo;

/**
 *
 * @author nets
 */
public class Articulo {

    private int id;
    private String nombre;
    private double precio;

    public Articulo(int id, String nombre, double precio) {
        // ...
    }

}
