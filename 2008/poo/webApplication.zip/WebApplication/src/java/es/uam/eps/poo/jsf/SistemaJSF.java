/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uam.eps.poo.jsf;

import es.uam.eps.poo.remote.SistemaRemoto;
import java.io.Serializable;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

/**
 *
 * @author mora
 */
public class SistemaJSF implements Serializable {

    protected SistemaRemoto sistema = null;

    /**
     * 
     * @return Devuelve el sistema remoto, conectando la primera vez que se necesita
     */
    public SistemaRemoto getSistema() {
        if (sistema == null) {
            try {
                sistema = connect();
            } catch (RemoteException ex) {
                Logger.getLogger(SistemaJSF.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NotBoundException ex) {
                Logger.getLogger(SistemaJSF.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return sistema;
    }

    /** Creates a new instance of SistemaJSF */
    public SistemaJSF() {
    }

    private SistemaRemoto connect() throws RemoteException, NotBoundException {
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }
        Registry registry = LocateRegistry.getRegistry(SistemaRemoto.Port);
        return (SistemaRemoto) registry.lookup(SistemaRemoto.ID);
    }


    /**
     *
     * @return Devuelve el array de Items para su uso en las páginas JSF
     */
    public SelectItem[] getAsignaturas() {
        SistemaRemoto s = getSistema();
        SelectItem[] result = null;
        try {
            String[] asignaturas = s.getAsignaturas();
            result = new SelectItem[asignaturas.length];
            for (int i = 0; i < asignaturas.length; i++) {
                result[i] = new SelectItem(asignaturas[i]);
            }
        } catch (RemoteException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public boolean isSystemReady(){
        return getSistema()!=null;
    }

    /**
     * Método de utilidad para localizar objetos en el contexto actual
     *
     * @param name Nombre de la variable (e.g. Managed Bean)
     * @return Objeto, ambitos application, request o session
     */
    public static Object resolveVariable(String name){
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getApplication().getVariableResolver()
                .resolveVariable(facesContext, name);
    }

    public static SistemaJSF getSistemaJSF(){
        return (SistemaJSF) SistemaJSF.resolveVariable("sistema");
    }
}
