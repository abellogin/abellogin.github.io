/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.jsf;

import es.uam.eps.poo.remote.AsignaturaRemota;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mora
 */

public class AsignaturaJSF {

    /** Creates a new instance of AsignaturaJSF */
    public AsignaturaJSF() {
    }
    protected String nombre;

    /**
     * Get the value of nombre
     *
     * @return the value of nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Set the value of nombre
     *
     * @param nombre new value of nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public AsignaturaRemota getAsignatura(){
        SistemaJSF s=SistemaJSF.getSistemaJSF();
        try {
            return s.getSistema().getAsignatura(nombre);
        } catch (RemoteException ex) {
            Logger.getLogger(AsignaturaJSF.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public String getInforme(){
        SistemaJSF s=SistemaJSF.getSistemaJSF();
        try {
            AsignaturaRemota a = s.getSistema().getAsignatura(nombre);
            return s.getSistema().getInformeResumenCalificacionesAsignatura(a);
        } catch (RemoteException ex) {
            Logger.getLogger(AsignaturaJSF.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
