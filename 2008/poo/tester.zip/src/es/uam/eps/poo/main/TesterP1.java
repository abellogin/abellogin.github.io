package es.uam.eps.poo.main;

import es.uam.eps.poo.Alumno;

/**
 * Tester de la primera práctica del POO del curso 2008-2009
 */
public class TesterP1 {

    /**
     * Crea un {@link Alumno} e imprime por pantalla sus datos
     */
    public static void main(String[] args) {
        Alumno alumno = new Alumno("Antonio", "López Pérez", "00000001R", "c/ Einstein 23", null);
        
        System.out.println("Los datos del alumno creado son:");
        System.out.println(alumno.toString());
    }

}
