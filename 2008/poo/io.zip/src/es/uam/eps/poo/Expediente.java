package es.uam.eps.poo;

public class Expediente {

}
