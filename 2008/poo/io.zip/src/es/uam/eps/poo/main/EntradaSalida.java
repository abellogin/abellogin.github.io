package es.uam.eps.poo.main;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Clase con ejemplo de entrada/salida en Java
 */
public class EntradaSalida implements Serializable {
    String entrada;
    
    public static void main(String[] args)
    {
        EntradaSalida io = new EntradaSalida();
        
        try {
            // Entrada de teclado
            BufferedReader bufferIn = new BufferedReader(new InputStreamReader(System.in));
            io.entrada = bufferIn.readLine();

            // Salida por pantalla
            System.out.println("---> Texto leido por teclado: " + io.entrada);
            
            // Escritura de un fichero binario (buscar en la ayuda la forma de invocar a los
            // distintos constructores de FileOutputStream)
            FileOutputStream streamOut = new FileOutputStream("salida.dat");
            ObjectOutputStream salida = new ObjectOutputStream(streamOut);
            // El objeto que se escribe tiene que ser serializable
            salida.writeObject(io);
            salida.close();
            
            // Lectura de un fichero binario
            FileInputStream streamIn = new FileInputStream("salida.dat");
            ObjectInputStream entrada = new ObjectInputStream(streamIn);
            EntradaSalida leido = (EntradaSalida) entrada.readObject();
            entrada.close();
            
            System.out.println("---> Texto leido por fichero: " + leido.entrada);
        }
        catch(Exception err) {
            System.out.println("Se ha producido un error: " + err);
        }
    }
}
