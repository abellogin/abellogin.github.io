package es.uam.eps.poo;

import java.io.Serializable;

/**
 *
 * @author Alejandro
 */
public class Alumno implements Serializable {

    private String nombre;
    private String apellidos;
    private String dni;
    private String direccion;
    private String telefono;
    private Expediente expediente;

    public Alumno(String nombre, String apellidos, String dni, String direccion, String telefono, Expediente expediente) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.direccion = direccion;
        this.telefono = telefono;
        this.expediente = expediente;
    }

    public String getDni() {
        return dni;
    }

    public Expediente getExpediente() {
        return expediente;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        String s = "";
        s += "DNI=" + dni + ",nombre=" + nombre + ",apellidos=" + apellidos +
                ",direccion=" + direccion + ",telefono=" + telefono +
                "\nExpediente=" + expediente;
        return s;
    }
}
