package es.uam.eps.poo.beans;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * Esta clase permite obtener en memoria una lista de {@link Asignatura}s
 *
 * @author Alejandro
 */
public class CargarInformacion {

    /**
     * Obtiene una lista de {@link Asignatura}s agrupadas por a�o acad�mico
     *
     * @return tabla formada por [a�o, lista de asignaturas de ese a�o]
     */
    public static HashMap<Integer, Asignatura> obtenerListaAsignaturasTeoria() {
        HashMap<Integer, Asignatura> asignaturas = new HashMap<Integer, Asignatura>();
        ArrayList<Asignatura> llave = null;
        int id = 0;
        // Primero
        // primer semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "�lgebra I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "An�lisis Matem�tico I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "F�sica I", 1, 1, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Inform�tica General", 1, 1, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Metodolog�a y Tecnolog�a de la Programaci�n I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.25)));
        // segundo semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "�lgebra II", 1, 2, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "An�lisis Matem�tico II", 1, 2, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "F�sica II", 1, 2, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura de Datos y de la Informaci�n I", 1, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Teconolog�a de Computadores I", 1, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        // id = 10
        // Segundo
        // primer semestre
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Metodolog�a y Tecnolog�a de la Programaci�n II", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.3), llave));
        llave = new ArrayList<Asignatura>(); // ig, etc I
        llave.add(asignaturas.get(4));
        llave.add(asignaturas.get(10));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Teconolog�a de Computadores II", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2), llave));
        llave = new ArrayList<Asignatura>(); // fis I, fis II
        llave.add(asignaturas.get(3));
        llave.add(asignaturas.get(8));
        id++;
        asignaturas.put(id, new Asignatura(id, "Electr�nica", 2, 1, 5.6, Asignatura.TIPO_TRONCAL, llave));
        llave = new ArrayList<Asignatura>(); // algebra I
        llave.add(asignaturas.get(1));
        id++;
        asignaturas.put(id, new Asignatura(id, "Matem�tica Discreta", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Econom�a General", 2, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        // segundo semestre
        llave = new ArrayList<Asignatura>(); // ig, mtp I, edi I
        llave.add(asignaturas.get(4));
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Operativos", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2), llave));
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura de Datos y de la Informaci�n II", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.25), llave));
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teor�a de Aut�matas y Lenguajes Formales I", 2, 2, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.15), llave));
        llave = new ArrayList<Asignatura>(); // am I, am II
        llave.add(asignaturas.get(2));
        llave.add(asignaturas.get(7));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estad�stica", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Econom�a de la Empresa", 2, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teor�a de Sistemas y Control", 2, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        // id = 21
        // Tercero
        // primer semestre
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Arquitectura e Ingenier�a de Computadores", 3, 1, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.35), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Inteligencia Artificial", 3, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Redes de Comunicaciones I", 3, 1, 5.6, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "An�lisis de Algoritmos", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Computaci�n Cient�fica I", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // so I
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Operativos II", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencias de la Computaci�n I (Multimedia)", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.2)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Dise�o de Circuitos Digitales", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        // id = 29
        // segundo semestre
        llave = new ArrayList<Asignatura>(); // ig
        llave.add(asignaturas.get(4));
        id++;
        asignaturas.put(id, new Asignatura(id, "Procesadores de Lenguaje", 3, 2, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingenier�a del Conocimiento", 3, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Redes de Comunicaciones II", 3, 2, 5.6, Asignatura.TIPO_TRONCAL, new Practica(0.25), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Programaci�n Orientada a Objetos", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.4), llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Ingenier�a Inform�tica I (L�gica)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Ciencias de la Computaci�n III (Reconocimiento de Patrones)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Arquitectura de Ordenadores I (Procesamiento Digital de Se�al)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        // id = 36
        // Cuarto
        // primer semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingenier�a del Software I", 4, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Inform�ticos I", 4, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Fundamentos de Neurocomputaci�n", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.35)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencia de la Computaci�n II (Programaci�n Orientada a Objetos II)", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teor�a de Aut�matas y Lenguajes Formales II", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.9)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Pr�cticas en Empresa", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingenier�a Inform�tica III", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Arquitectura de Ordenadores (Redes III)", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        // id = 44
        // segundo semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingenier�a del Software II", 4, 2, 8.4, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Inform�ticos II", 4, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.4)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Gr�ficos", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.5)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Modelizaci�n y Simulaci�n por Ordenador", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingenier�a Inform�tica II (Computaci�n Paralela)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.6)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Pr�cticas en Empresa", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingenier�a Inform�tica IV (Rob�tica)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencia de la Computaci�n IV (Criptograf�a)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        // id = 52
        return asignaturas;
    }

    /**
     * M�todo que permite imprimir la informaci�n m�s relevante
     * de un conjunto de asignaturas.
     * Al contrario del toString() este m�todo no muestra
     * toda la informaci�n de una {@link Asignatura}
     *
     * @param asignaturas asignaturas a imprimir
     */
    public static void imprimirAsignaturas(HashMap<Integer, Asignatura> asignaturas) {
        System.out.println("Id|Nombre|Curso|Semestre");
        for (Asignatura a : asignaturas.values()) {
            System.out.println(a.getId() + "|" + a.getNombre() + "|" + a.getCursoAcademico() + "|" + a.getSemestre());
        }
    }

    public static void main(String[] args){
        imprimirAsignaturas(obtenerListaAsignaturasTeoria());
    }
}
