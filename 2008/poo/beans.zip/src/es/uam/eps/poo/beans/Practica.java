package es.uam.eps.poo.beans;

import java.io.Serializable;

/**
 *
 * Clase que representa la informaci�n com�n
 * (compartida por todos los alumnos)
 * de una asignatura pr�ctica
 *
 * @author Alejandro
 */
public class Practica implements Serializable {

    private double porcentaje;

    /**
     * Crea una asignatura pr�ctica.
     * En caso de que el porcentaje sea 0,
     * indica que esta asignatura es de tipo binario
     *
     * @param porcentaje porcentaje de nota que cuenta la pr�ctica, si es 0 la asignatura es binaria
     */
    public Practica(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    /**
     * Obtiene el porcentaje con el que contribuye a la nota esta asignatura
     *
     * @return porcentaje
     */
    public double getPorcentaje() {
        return porcentaje;
    }

    /**
     * Devuelve true si esta asignatura es binaria
     *
     * @return true si la asignatura es binaria (porcentaje es 0)
     */
    public boolean esBinaria() {
        return porcentaje == 0.0;
    }

    @Override
    public String toString() {
        return "Practica: porcentaje=" + porcentaje;
    }
}
