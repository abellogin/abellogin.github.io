package es.uam.eps.poo.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mora
 */
public interface SistemaRemoto extends Remote {
    /**
     * Nombre con el que se registra en RMI
     */
    public static final String ID="Servidor";
    /**
     * Puerto del registro
     */
    public static final int Port=1234;
    /**
     *
     * @return Busca una asignatura por nombre
     */
    AsignaturaRemota getAsignatura(String nombre)  throws RemoteException;

    /**
     *
     * @return Devuelve la lista de nombres de las asignaturas
     */
    String[] getAsignaturas() throws RemoteException;

    String getInformeResumenCalificacionesAsignatura(AsignaturaRemota a) throws RemoteException;

}
