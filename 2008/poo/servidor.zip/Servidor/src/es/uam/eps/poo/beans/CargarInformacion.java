package es.uam.eps.poo.beans;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * Esta clase permite obtener en memoria una lista de {@link Asignatura}s
 *
 * @author Alejandro
 */
public class CargarInformacion {

    /**
     * Obtiene una lista de {@link Asignatura}s agrupadas por año académico
     *
     * @return tabla formada por [año, lista de asignaturas de ese año]
     */
    public static HashMap<Integer, Asignatura> obtenerListaAsignaturasTeoria() {
        HashMap<Integer, Asignatura> asignaturas = new HashMap<Integer, Asignatura>();
        ArrayList<Asignatura> llave = null;
        int id = 0;
        // Primero
        // primer semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Álgebra I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "Análisis Matemático I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "Física I", 1, 1, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Informática General", 1, 1, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Metodología y Tecnología de la Programación I", 1, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.25)));
        // segundo semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Álgebra II", 1, 2, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Análisis Matemático II", 1, 2, 6.0, Asignatura.TIPO_OBLIGATORIA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Física II", 1, 2, 6.0, Asignatura.TIPO_TRONCAL));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura de Datos y de la Información I", 1, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Teconología de Computadores I", 1, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        // id = 10
        // Segundo
        // primer semestre
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Metodología y Tecnología de la Programación II", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.3), llave));
        llave = new ArrayList<Asignatura>(); // ig, etc I
        llave.add(asignaturas.get(4));
        llave.add(asignaturas.get(10));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Teconolog�a de Computadores II", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2), llave));
        llave = new ArrayList<Asignatura>(); // fis I, fis II
        llave.add(asignaturas.get(3));
        llave.add(asignaturas.get(8));
        id++;
        asignaturas.put(id, new Asignatura(id, "Electrónica", 2, 1, 5.6, Asignatura.TIPO_TRONCAL, llave));
        llave = new ArrayList<Asignatura>(); // algebra I
        llave.add(asignaturas.get(1));
        id++;
        asignaturas.put(id, new Asignatura(id, "Matemática Discreta", 2, 1, 6.0, Asignatura.TIPO_TRONCAL, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Economía General", 2, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        // segundo semestre
        llave = new ArrayList<Asignatura>(); // ig, mtp I, edi I
        llave.add(asignaturas.get(4));
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Operativos", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.2), llave));
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura de Datos y de la Información II", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.25), llave));
        llave = new ArrayList<Asignatura>(); // mtp I, edi I
        llave.add(asignaturas.get(5));
        llave.add(asignaturas.get(9));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teoría de Autómatas y Lenguajes Formales I", 2, 2, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.15), llave));
        llave = new ArrayList<Asignatura>(); // am I, am II
        llave.add(asignaturas.get(2));
        llave.add(asignaturas.get(7));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estadística", 2, 2, 6.0, Asignatura.TIPO_TRONCAL, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Economía de la Empresa", 2, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teoría de Sistemas y Control", 2, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        // id = 21
        // Tercero
        // primer semestre
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Arquitectura e Ingeniería de Computadores", 3, 1, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.35), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Inteligencia Artificial", 3, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Redes de Comunicaciones I", 3, 1, 5.6, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Análisis de Algoritmos", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Computación Científica I", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // so I
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Operativos II", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencias de la Computación I (Multimedia)", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.2)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Estructura y Diseño de Circuitos Digitales", 3, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        // id = 29
        // segundo semestre
        llave = new ArrayList<Asignatura>(); // ig
        llave.add(asignaturas.get(4));
        id++;
        asignaturas.put(id, new Asignatura(id, "Procesadores de Lenguaje", 3, 2, 7.2, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingeniería del Conocimiento", 3, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0), llave));
        llave = new ArrayList<Asignatura>(); // etc II
        llave.add(asignaturas.get(12));
        id++;
        asignaturas.put(id, new Asignatura(id, "Redes de Comunicaciones II", 3, 2, 5.6, Asignatura.TIPO_TRONCAL, new Practica(0.25), llave));
        llave = new ArrayList<Asignatura>(); // edi II
        llave.add(asignaturas.get(17));
        id++;
        asignaturas.put(id, new Asignatura(id, "Programación Orientada a Objetos", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.4), llave));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Ingeniería Informática I (Lógica)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Ciencias de la Computación III (Reconocimiento de Patrones)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzadas en Arquitectura de Ordenadores I (Procesamiento Digital de Señal)", 3, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        // id = 36
        // Cuarto
        // primer semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingeniería del Software I", 4, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Informáticos I", 4, 1, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Fundamentos de Neurocomputación", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.35)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencia de la Computación II (Programación Orientada a Objetos II)", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Teoría de Autómatas y Lenguajes Formales II", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.9)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Prácticas en Empresa", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingeniería Informática III", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Arquitectura de Ordenadores (Redes III)", 4, 1, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.0)));
        // id = 44
        // segundo semestre
        id++;
        asignaturas.put(id, new Asignatura(id, "Ingeniería del Software II", 4, 2, 8.4, Asignatura.TIPO_TRONCAL, new Practica(0.0)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Sistemas Informáticos II", 4, 2, 6.0, Asignatura.TIPO_TRONCAL, new Practica(0.4)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Gráficos", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.5)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Modelización y Simulación por Ordenador", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingeniería Informática II (Computación Paralela)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.6)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Prácticas en Empresa", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ingeniería Informática IV (Robótica)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        id++;
        asignaturas.put(id, new Asignatura(id, "Temas Avanzados en Ciencia de la Computación IV (Criptografía)", 4, 2, 5.6, Asignatura.TIPO_OPTATIVA, new Practica(0.3)));
        // id = 52
        return asignaturas;
    }

    /**
     * Método que permite imprimir la información más relevante
     * de un conjunto de asignaturas.
     * Al contrario del toString() este método no muestra
     * toda la información de una {@link Asignatura}
     *
     * @param asignaturas asignaturas a imprimir
     */
    public static void imprimirAsignaturas(HashMap<Integer, Asignatura> asignaturas) {
        System.out.println("Id|Nombre|Curso|Semestre");
        for (Asignatura a : asignaturas.values()) {
            System.out.println(a.getId() + "|" + a.getNombre() + "|" + a.getCursoAcademico() + "|" + a.getSemestre());
        }
    }

    public static void main(String[] args){
        imprimirAsignaturas(obtenerListaAsignaturasTeoria());
    }
}
