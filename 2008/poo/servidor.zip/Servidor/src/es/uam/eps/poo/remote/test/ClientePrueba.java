/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.remote.test;

import es.uam.eps.poo.remote.AsignaturaRemota;
import es.uam.eps.poo.remote.SistemaRemoto;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mora
 */
public class ClientePrueba {
    public static void main(String[] args){
        try {
            Registry r=LocateRegistry.getRegistry(SistemaRemoto.Port);
            SistemaRemoto s = (SistemaRemoto) r.lookup(SistemaRemoto.ID);
            String[] asignaturas=s.getAsignaturas();
            AsignaturaRemota a=s.getAsignatura(asignaturas[0]);
            System.out.println(s.getInformeResumenCalificacionesAsignatura(a));
        } catch (NotBoundException ex) {
            Logger.getLogger(ClientePrueba.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AccessException ex) {
            Logger.getLogger(ClientePrueba.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(ClientePrueba.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
