/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author mora
 */
public interface AsignaturaRemota extends Remote {
    int getCursoAcademico() throws RemoteException;
    int getId() throws RemoteException;
    String getNombre() throws RemoteException;
    double getNumeroDeCreditos() throws RemoteException;
    int getSemestre() throws RemoteException;    
}
