/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.uam.eps.poo.remote.test;

import es.uam.eps.poo.beans.Asignatura;
import es.uam.eps.poo.remote.AsignaturaRemota;
import es.uam.eps.poo.remote.SistemaRemoto;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mora
 */
public class ImplSistemaRemoto implements SistemaRemoto {

    protected Map<String, AsignaturaRemota> asignaturas;


    public ImplSistemaRemoto(Collection<Asignatura> asignaturas) throws RemoteException{
        this.asignaturas = new HashMap<String, AsignaturaRemota>();
        for (AsignaturaRemota a : asignaturas) {
            this.asignaturas.put(a.getNombre(), a);
        }
    }

    /**
     *
     * @return Devuelve la lista de nombres de las asignaturas
     */
    public String[] getAsignaturas() {
        String[] result= new String[asignaturas.size()];
        return asignaturas.keySet().toArray(result);
    }

    /**
     *
     * @return Busca una asignatura por nombre
     */
    public AsignaturaRemota getAsignatura(String nombre){
        return asignaturas.get(nombre);
    }

    public String getInformeResumenCalificacionesAsignatura(AsignaturaRemota a){
        try {
            return "Este es un informe de resumen de calificaciones para la asignatura: " + a.getNombre() + "\n" + "Curso:\t" + a.getCursoAcademico() + "\n" + "Creditos:\t" + a.getNumeroDeCreditos() + "\n";
        } catch (RemoteException ex) {
            Logger.getLogger(ImplSistemaRemoto.class.getName()).log(Level.SEVERE, null, ex);
            return ex.toString();
        }

    }


}
